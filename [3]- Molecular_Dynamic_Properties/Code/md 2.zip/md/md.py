import numpy as np
import random
import matplotlib.pyplot as plt
import statistics

import math

def minimum_image(r, L):
    """
    required for: displacement_table(), advance()
    args:
        r: array of any shape
        L: side length of cubic box
    returns:
        array of the same shape as r,
        the minimum image of r
    """
    return r - L*np.round(r / L)

def cubic_lattice(tiling, L):
    """
    required for: initialization

    args:
        tiling (int): determines number of coordinates,
        by tiling^3
        L (float): side length of simulation box
    returns:
        array of shape (tiling**3, 3): coordinates on a cubic lattice,
        all between -0.5L and 0.5L
    """
    coord = []
    for x in range(tiling):
        for y in range(tiling):
            for z in range(tiling):
                coord.append([x,y,z])
    coord = np.array(coord)/tiling
    coord -= 0.5
    return coord*L
def vacf(all_vel, t1, t2):
    veloc_sum = 0
    for i in range(0, len(all_vel[0])):
        veloc_sum += np.dot(all_vel[t1][i], all_vel[t2][i])
    return veloc_sum/len(all_vel[0])
def get_temperature(mass, velocities):
    """
    calculates the instantaneous temperature
    required for: initial_velocities()
    
    args:
        mass (float): mass of particles;
        it is assumed all particles have the same mass
        velocities (array): velocities of particles,
        assumed to have shape (N, 3)
    returns:
        float: temperature according to equipartition
    """
    N = len(velocities)
    deg_of_freedom = 3*N
    total_vsq = np.einsum('ij,ij', velocities, velocities)
    return mass*total_vsq / deg_of_freedom

def initial_velocities(N, m, T):
    """
    initialize velocities at a desired temperature
    required for: initialization

    args:
        N (int): number of particles
        m (float): mass of particles
        T (float): desired temperature
    returns:
        array: initial velocities, with shape (N, 3)
    """
    velocities = np.random.rand(num_particles, 3)
    #center velocities
    new_v = velocities - 0.5
    #zero the total velocity
    total_v = np.sum(new_v, axis=0)
    new_v -= total_v / num_particles
    #get the right temperature
    current_temp = get_temperature(mass, new_v)
    factor  = np.sqrt(T / current_temp)
    new_v *= factor
    return new_v

def displacement_table(coordinates, L):
    """
    required for: force(), advance()

    args:
        coordinates (array): coordinates of particles,
        assumed to have shape (N, 3)
        e.g. coordinates[3,0] should give the x component
        of particle 3
        L (float): side length of cubic box,
        must be known in order to compute minimum image
    returns:
        array: table of displacements r
        such that r[i,j] is the minimum image of
        coordinates[i] - coordinates[j]
    """
    table = coordinates[:,np.newaxis,:] - coordinates[np.newaxis,:,:]
    return minimum_image(table, L)

def kinetic(m, v):
    """
    required for measurement

    args:
        m (float): mass of particles
        v (array): velocities of particles,
        assumed to be a 2D array of shape (N, 3)
    returns:
        float: total kinetic energy
    """
    total_vsq = np.einsum('ij,ij', v, v)
    return 0.5*m*total_vsq

def potential(dist, rc):
    """
    required for measurement

    args:
        dist (array): distance table with shape (N, N)
        i.e. dist[i,j] is the distance
        between particle i and particle j
        in the minimum image convention
        note that the diagonal of dist can be zero
        rc (float): cutoff distance for interaction
        i.e. if dist[i,j] > rc, the pair potential between
        i and j will be 0
    returns:
        float: total potential energy
    """
    r = np.copy(dist)
    r[np.diag_indices(len(r))] = np.inf
    v = 4*np.power(r, -6)*(np.power(r, -6) - 1)
    vc = 4*np.power(rc, -6)*(np.power(rc, -6) - 1)
    v[r < rc] -= vc #shift
    v[r >= rc] = 0 #cut
    return 0.5*np.sum(v)

def force(disp, dist, rc):
    """
    required for: advance()

    args:
        disp (array): displacement table,
        with shape (N, N, 3)
        dist (array): distance table, with shape (N, N)
        can be calculated from displacement table,
        but since there is a separate copy available
        it is just passed in here
        rc (float): cutoff distance for interaction
        i.e. if dist[i,j] > rc, particle i will feel no force
        from particle j
    returns:
        array: forces f on all particles, with shape (N, 3)
        i.e. f[3,0] gives the force on particle i
        in the x direction
    """
    r = np.copy(dist)
    r[np.diag_indices(len(r))] = np.inf
    magnitude = 1./r**8
    magnitude *= 2./r**6 - 1
    magnitude *= 24
    magnitude[r >= rc] = 0
    val = magnitude[:,:,np.newaxis]*disp
    val = np.sum(val, axis=1)
    return val

def my_diffusion_constant(vacf):
    """ Calculate the diffusion constant from the
    velocity-velocity auto-correlation function (vacf).
    
    note: take a look at numpy.trapz() and see if you can use it here!

    Args:
      vacf (np.array): shape (nt,), vacf sampled at
       nt time steps from t=0 to nt*dt. dt is set to 0.032.
    Returns:
      float: the diffusion constant calculated from the vacf.
    """
    dt = 0.032 #NOTE Do not change this value.
    return np.trapz(vacf,dx=dt)/3

def advance(pos, vel, mass, dt, disp, dist, rc, L):
    """
    advance system according to velocity verlet

    args:
        pos (array): coordinates of particles
        val (array): velocities of particles
        mass (float): mass of particles
        dt (float): timestep by which to advance
        disp (array): displacement table
        dist (array): distance table
        rc (float): cutoff
        L (float): length of cubic box
    returns:
        array, array, array, array:
        new positions, new velocities, new displacement table,
        and new distance table
    """
    accel = force(disp, dist, rc) / mass
    #move
    vel_half = vel + 0.5*dt*accel
    pos_new = pos + dt*vel_half
    pos_new = minimum_image(pos_new, L) #not strictly necessary
    disp_new = displacement_table(pos_new, L)
    dist_new = np.linalg.norm(disp_new, axis=-1)
    #repeat force calculation for new pos
    accel = force(disp_new, dist_new, rc) / mass
    #finish move
    vel_new = vel_half + 0.5*dt*accel
    return pos_new, vel_new, disp_new, dist_new

def my_calc_rhok(kvecs, pos):
  """ Calculate the fourier transform of particle density.

  Args:
    kvecs (np.array): array of k-vectors, shape (nk, ndim)
    pos (np.array): particle positions, shape (natom, ndim)
  Return:
    array of shape (nk,): fourier transformed density rho_k
  """
  array = []
  for i in range(len(kvecs)):
      sum =0 
      for j in range(len(pos)):
          sum += np.exp(-1j*np.dot(kvecs[i], pos[j]))
      array.append(sum)
      sum =0
  return array 
  pass

def my_calc_sk(kvecs, pos):
  """ Calculate the structure factor S(k).

  Args:
    kvecs (np.array): array of k-vectors, shape (nk, ndim)
    pos (np.array): particle positions, shape (natom, ndim)
  Return:
    array of shape (nk,): structure factor s(k)
  """
  array = np.zeros(len(kvecs))
  a = my_calc_rhok(kvecs,pos)
  b = my_calc_rhok(-kvecs,pos)
  n = len(pos)
  for i in range(len(kvecs)):
      array[i] = a[i] *b[i]
  return array/n
  pass

def my_diffusion_constant(vacf):
    """ Calculate the diffusion constant from the
    velocity-velocity auto-correlation function (vacf).
    
    note: take a look at numpy.trapz() and see if you can use it here!

    Args:
      vacf (np.array): shape (nt,), vacf sampled at
       nt time steps from t=0 to nt*dt. dt is set to 0.032.
    Returns:
      float: the diffusion constant calculated from the vacf.
    """
    dt = 0.032 #NOTE Do not change this value.
    return np.trapz(vacf,dx=dt)/3

def my_pair_correlation(dists, natom, nbins, dr, lbox):
    histogram = np.histogram(dists, bins=nbins, range=(0, nbins*dr))
    r = (histogram[1] + dr/2)[:-1] # centers of the bins
    p_sum = 0
    C_const= 1/(math.pi/6)
    res_arr = []
    for i in range(0,len(r)):
        density = natom/lbox**3
        vol = 4*np.pi/3*((r[i]+dr/2)**3 - (r[i] - dr/2)**3)
        res_arr.append(density*vol)
        p_sum += (density*vol)
    ratio = natom*(natom-1)/2
    for i in range(0,len(res_arr)):
        res_arr[i] *= ratio/p_sum
        res_arr[i] = histogram[0][i]/res_arr[i]*C_const
    return res_arr

def my_legal_kvecs(maxn, lbox):

    kvecs = np.zeros(((maxn + 1)**3, 3))

    for j in range(maxn+1): 
        for k in range((maxn+1)**2):
            kvecs[((maxn+1)**2)*j+k,0] = j*2*math.pi/lbox
    
    for j in range((maxn+1)): 
        for k in range((maxn+1)):
            for l in range(maxn+1):
                kvecs[j*(maxn+1)**2+(maxn+1)*k+l,1] = k*2*math.pi/lbox
    
    for j in range((maxn+1)): 
        for k in range((maxn+1)):
            for l in range((maxn+1)):
                kvecs[j*(maxn+1)**2+(maxn+1)*k+l,2] = l*2*math.pi/lbox
            
    return np.array(kvecs)

def thermostat(v, m, T, prob):
    """
    args:
        v (array): velocities of particles
        m (float): mass of particles
        T (float): target temperature
        prob (float): collision probability,
            a number of between 0 and 1
    returns:
        nothing, but v is modified
    """
    for i in range(len(v)): 
        rand= random.random() 
        if(rand <= prob):
            for h in range(3): 
                v[i][h] = np.random.randn()*math.sqrt(T/m)

# for reproducibility
np.random.seed(466)


# parameters
num_particles = 64
temperature = 0.728
length = 4.2323167
cutoff = length / 2
mass = 48
timestep = 0.03

# system
coordinates = cubic_lattice(4, length)
velocities = initial_velocities(num_particles, mass, temperature)

# tables required to compute quantities like forces, energies
displacements = displacement_table(coordinates, length)
distances = np.linalg.norm(displacements, axis=-1)
pair_correlation = []

# measure
time = 0 
time_array = []
temp_array = []
st_array = []
all_vel=[]
pair_corr = []
sk = []
array = (my_legal_kvecs(5, length))
arr_k_vec_mag = []
dummy = 'auto'
for _ in range(10000):
    coordinates, velocities, displacements, distances = advance(coordinates,\
            velocities, mass, timestep, displacements, distances, cutoff,\
            length)
    thermostat(velocities, mass, temperature, .01)
    time_array.append(time)
    temp_array.append(get_temperature(mass,velocities))
    time += timestep
    # temp = []
    # for v in velocities:
    #     temp.append(v)
    # all_vel.append(temp)

print(temp_array)
plt.plot(temp_array)
plt.title('1% Collision Probability')
plt.xlabel('time')
plt.ylabel('temperature')
plt.show()
# kvectors = my_legal_kvecs(3,length)
# s_k = my_calc_sk(kvectors, coordinates)
# plt.plot(s_k[1:])
# plt.title('Plot of S(k)')
# plt.xlabel('k vectors')
# plt.ylabel('structure factor')
# plt.show()







# np.savetxt("resulted.txt", my_calc_sk(my_legal_kvecs(3, length), coordinates))
# plt.plot(my_pair_correlation(distances,num_particles,35,cutoff/8,length))
# plt.show()

    
            

    # st_array.append(get_temperature(mass,velocities))
    # thermostat(velocities, mass, temperature, .01)
    # time_array.append(time)
    # temp_array.append(get_temperature(mass,velocities))
    # time += timestep
    # temp = []
    # for v in velocities:
    #     temp.append(v)
    # all_vel.append(temp)


# vacf_arr = []
# for i in range(0,len(all_vel) - 1):
#     vacf_arr.append(vacf(all_vel,i,i+1))
# print(my_diffusion_constant(vacf_arr[0:300])) # remember to filter out noise
# save to disk

# plt.plot(vacf_arr)
# plt.title('Plotted velocity autocorrelation function')
# plt.xlabel('sample number')
# plt.ylabel('velocity auto-correlation function')
# plt.show()